package XPaths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class New_userxpath {
	WebDriver ldriver;
	
	 public OTP_authentication database;
	
	public  New_userxpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}
	
	@FindBy (xpath ="(//button[@type=\"button\"])[1]")
	 WebElement dashboard_click;
	
	@FindBy (xpath = "//span[text()=\"New User\"]")
	 WebElement New_user;
	
	@FindBy (xpath = "(//div[@role=\"button\"])[1]")
	 WebElement User_type;
	
	@FindBy (xpath = "//li[text()=\"Center Head\"]")
	 WebElement sel_head;
	
	@FindBy (xpath = "(//div[@role=\"button\"])[2]")
	 WebElement Centre_clk;
	
	@FindBy (xpath = "//li[text()=\"Dadar\"]")
	 WebElement sel_dadar;
	
	@FindBy (xpath = "//input[@id=\"uname\"]")
	 WebElement Enter_name;
	
	@FindBy (xpath = "//input[@id=\"phone\"]")
	 WebElement Enter_phone;
	
	@FindBy (xpath = "//span[text()=\" Add\"]")
	 WebElement Add_btn;
	
	@FindBy (xpath = "//span[text()=\"Home\"]")
	 WebElement Home_btn;
	
	public void Adduser() throws Exception {
		
		Thread.sleep(2000);
		dashboard_click.click();
		Thread.sleep(2000);
		New_user.click();
		Thread.sleep(2000);
		User_type.click();
		Thread.sleep(2000);
		sel_head.click();
		Thread.sleep(2000);
		Centre_clk.click();
		Thread.sleep(2000);
		sel_dadar.click();
		Thread.sleep(1000);
        Enter_name.sendKeys("Testnewuser");
        Thread.sleep(1000);
        Enter_phone.sendKeys("7896868787");
        Thread.sleep(1000);
        Add_btn.click();
        Thread.sleep(2000);
        Home_btn.click();
		
	}
	
}

  
