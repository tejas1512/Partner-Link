package XPaths;

import javax.xml.xpath.XPath;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class Track_xpath {
	
	
		WebDriver ldriver;
		  public OTP_authentication database;
		  
		  JavascriptExecutor js;
		
	public Track_xpath(WebDriver rDriver) 
		{

			ldriver=rDriver;
			PageFactory.initElements(rDriver,this);
	    }
	//span[text()="Filters "]
	
	
	    @FindBy (xpath ="//span[text()=\"Track\"]")
	     WebElement Track_app;	
	     
	     @FindBy (xpath ="(//button[@type=\"button\"])[2]")
	     WebElement Filter;
	     
	     @FindBy (xpath ="//button[@id=\"2\"]")
	     WebElement centre_click;
	     
	     @FindBy (xpath ="//span[text()=\"mumbai loc\"]")
	     WebElement mumbai_clk;
	     
//	     @FindBy (xpath ="(//input[@type=\"radio\"])[5]")
//	     WebElement radio_clk;
	  
	 	@FindBy (xpath ="//span[text()=\"Apply\"]")
	     WebElement Apply_click;	

		@FindBy (xpath = "(//span[text()=\"PRATIK BENDAL\"])[1]")
		WebElement Approved_link;
		
		@FindBy (xpath = "//span[text()=\"EDIT\"]")
		 WebElement edit_loan_details;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_edit_loan;
		
		@FindBy (xpath = "(//span[text()=\"EDIT\"])[2]")
		 WebElement Edit_personal_loan;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_personal;
		
		@FindBy (xpath = "(//span[text()=\"EDIT\"])[3]")
		 WebElement Edit_address;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_address;
		
		@FindBy (xpath = "(//span[text()=\"EDIT\"])[4]")
		 WebElement Edit_income_detail;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_income;
		
		@FindBy (xpath = "(//span[text()=\"EDIT\"])[5]")
		 WebElement Edit_document_proof;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_document_proof;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_home_page_1;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_home_page_2;
		
		@FindBy (xpath = "//input[@id=\"search\"]")
		 WebElement input_name;
		
		@FindBy (xpath = "(//button[@type=\"button\"])[3]")
		 WebElement search_btn;
		
		@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
		 WebElement back_home_page_3;
		
		
		
		
		
		
		
		public void Event_Track() throws Exception {
			
			js=(JavascriptExecutor)ldriver;
			Thread.sleep(1000);
             Track_app.click();
			
             Thread.sleep(2000);
             Filter.click();
             Thread.sleep(1000);
            centre_click.click();
            Thread.sleep(2000);
           mumbai_clk.click();
            Thread.sleep(2000);
            Apply_click.click();
			Thread.sleep(2000);
			js.executeScript("arguments[0].click();",Approved_link);
			//Approved_link.click();
			Thread.sleep(2000);
			edit_loan_details.click();
			Thread.sleep(2000);
			back_edit_loan.click();
			Thread.sleep(1000);
			Edit_personal_loan.click();
			Thread.sleep(2000);
			back_personal.click();
			Thread.sleep(1000);
			Edit_address.click();
			System.out.println("Address is invisisble");
			Thread.sleep(1000);
			back_address.click();
			Thread.sleep(1000);
			Edit_income_detail.click();
			Thread.sleep(1000);
			back_income.click();
			Thread.sleep(1000);
			Edit_document_proof.click();
			Thread.sleep(1000);
			back_document_proof.click();
			Thread.sleep(1000);
			back_home_page_1.click();
			Thread.sleep(1000);
			back_home_page_2.click();
			
	}
		
		public void search_Event() throws Exception {
			
			Thread.sleep(1000);
			Track_app.click();
			Thread.sleep(1000);
			input_name.sendKeys("pratik");
			Thread.sleep(1000);
			search_btn.click();
			Thread.sleep(1000);
			back_home_page_3.click();
			
			
			
		}


}
