package XPaths;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.mysql.cj.x.protobuf.MysqlxExpect.Open.Condition.Key;

import Database_connectivity.OTP_authentication;

public class CreateAppXpath {
	
	String filepath="C:\\Users\\Lenovo\\Downloads\\2010catalog_2.3mb.pdf";
	WebDriver ldriver;
	 public OTP_authentication database;
	  
	  JavascriptExecutor js;
	
 public CreateAppXpath(WebDriver rDriver) 
	{

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
    }
 
 //LoanDetails Xpath
 
 @FindBy (xpath ="(//button[@type=\"button\"])[12]")
 WebElement Create_btn;	
 
 @FindBy (xpath ="//span[text()=\"Start Here\"]")
 WebElement Start_btn;
 
 @FindBy (xpath ="(//div)[13]")
 WebElement centre_dropdown;
 
 @FindBy (xpath ="//li[text()=\"Dadar\"]")
 WebElement dadar_btn;

@FindBy (xpath ="//input[@id=\"name\"]")
 WebElement name_btn;	

@FindBy (xpath = "//input[@id=\"phone\"]")
WebElement mobile_number;

@FindBy (xpath = "(//div)[28]")
 WebElement preferred_language;

@FindBy (xpath = "//li[text()=\"English\"]")
 WebElement English_btn;

@FindBy (xpath = "(//div)[32]")
 WebElement product_name;

@FindBy (xpath = "//li[text()=\"CDAC\"]")
 WebElement CDAC_click;

@FindBy (xpath = "//input[@id=\"duration_year\"]")
 WebElement Duration_year;

@FindBy (xpath = "//input[@id=\"duration_month\"]")
WebElement Duration_month;

@FindBy (xpath = "//input[@id=\"loan_amount\"]")
WebElement loan_amount ;

@FindBy (xpath = "(//button[@type=\"button\"])[2]")
WebElement show_plans;

@FindBy (xpath = "//span[text()=\"12 EMI | 0₹\"]")
WebElement EMI_months;

@FindBy (xpath = "//span[text()=\"Skip\"]")
WebElement Skip_otp;

//personal_details xpath

@FindBy (xpath = "(//div)[31]")
WebElement gender_click ;

@FindBy (xpath = "//li[text()=\"MALE\"]")
WebElement Male_click;

@FindBy (xpath = "//input[@id=\"pan\"]")
WebElement pan_num;
 
//  DOB_calendar

@FindBy (xpath = "(//div)[39]")
WebElement DOB_click;

@FindBy (xpath = "//a[@title=\"Choose a year\"]")
WebElement choose_year;

@FindBy (xpath = "//a[@title=\"Last decade\"]")
WebElement back_calendar ;

@FindBy (xpath = "//a[text()=\"1996\"]")
WebElement Click_year;

@FindBy (xpath = "//a[@title=\"Choose a month\"]")
WebElement choose_month ;

@FindBy (xpath = "//a[text()=\"May\"]")
WebElement Select_month ;

@FindBy (xpath = "//div[text()=\"17\"]")
WebElement select_date;

//personal_detail
@FindBy (xpath = "//input[@id=\"email\"]")
WebElement Email_id;

@FindBy (xpath = "//span[text()=\"Next\"]")
WebElement Next_btn;

//Enter Address

@FindBy (xpath = "//input[@id=\"address\"]")
WebElement Flat_address;

@FindBy (xpath = "(//input[@id=\"google_location\"])[1]")
WebElement Landmark;

@FindBy (xpath = "(//input[@id=\"city\"])[1]")
WebElement City_selected;

@FindBy (xpath = "(//div[@role=\"button\"])[2]")
WebElement State_click ;

@FindBy (xpath = "(//ul[@role=\"listbox\"])/li[21]")
WebElement select_maha ;

@FindBy (xpath = "(//input[@id=\"pincode\"])[1]")
WebElement Select_pincode;

@FindBy (xpath = "(//span[text()=\"Address Type *\"])[1]")
WebElement Address_type ;

@FindBy (xpath = "(//input[@type=\"radio\"])[4]")
WebElement Radio_click ;

@FindBy (xpath = "//span[text()=\"Ok\"]")
WebElement Address_ok ;

@FindBy (xpath = "//input[@name=\"is_permanent\"]")
WebElement Toggle_btn ;

@FindBy (xpath = "//span[text()=\"Next\"]")
WebElement Next_address ;

//Profession Tpye

@FindBy (xpath = "//span[text()=\"Profession Type *\"]")
WebElement Pro_type ;

@FindBy (xpath = "//span[text()=\"Salaried\"]")
WebElement select_sal;

@FindBy (xpath = "//span[text()=\"Ok\"]")
WebElement select_sal_ok;

@FindBy (xpath = "//input[@id=\"monthly_income\"]")
WebElement monthly_income ;

@FindBy (xpath = "//input[@id=\"company_search\"]")
WebElement company_search;

@FindBy (xpath = "//span[text()=\"Company Type *\"]")
WebElement com_type;

@FindBy (xpath = "//span[text()=\"Private Limited\"]")
WebElement select_comp ;

@FindBy (xpath = "//span[text()=\"Ok\"]")
WebElement select_comp_ok;

@FindBy (xpath = "//input[@id=\"designation\"]")
WebElement designation;

@FindBy (xpath = "//input[@id=\"department\"]")
WebElement department_clk;

@FindBy (xpath = "//span[text()=\"Next\"]")
WebElement Next_income;

//Document_upload

@FindBy (xpath = "//span[text()=\"Bank Statement\"]")
WebElement bank_stat_clk;

@FindBy (xpath = "(//button[@type=\"button\"])[2]")
WebElement upload_clk;

@FindBy (xpath = "//span[text()=\"Next\"]")
WebElement next_document;

@FindBy (xpath = "//span[text()=\"Skip\"]")
WebElement Skip_clk;



public void loan_detail_1() throws Exception {
    	
    	Thread.sleep(2000);
    	Create_btn.click();
    	Thread.sleep(1000);
    	centre_dropdown.click();
    	Thread.sleep(1000);
    	dadar_btn.click();
    	Thread.sleep(1000);
    	Start_btn.click();
    	Thread.sleep(1000);
    	name_btn.sendKeys("Testautomation");
    	mobile_number.sendKeys("7509989899");
    	Thread.sleep(1000);
    	preferred_language.click();
    	Thread.sleep(1000);
    	English_btn.click();
    	Thread.sleep(1000);
    	product_name.click();
    	Thread.sleep(1000);
    	CDAC_click.click();
    	Thread.sleep(1000);
    	Duration_year.sendKeys("1");
    	Duration_month.sendKeys("1");
    	Thread.sleep(1000);
    	loan_amount.sendKeys("50000");
    	Thread.sleep(1000);
    	show_plans.click();
    	Thread.sleep(1000);
    	EMI_months.click();
    	Thread.sleep(1000);
    	Skip_otp.click();
    	
}
     public void personal_details_2() throws Exception {
    	 
    	Thread.sleep(2000);
    	gender_click.click();
    	Thread.sleep(1000);
    	Male_click.click();
    	Thread.sleep(2000);
    	pan_num.sendKeys("CHWPB9090Y");
    	Thread.sleep(2000);
    	Email_id.sendKeys("hjhjhh@creditfair.in");
    	
    	
 }
    public void Rc_Calendar_2() throws Exception {
    	Thread.sleep(2000);
    	DOB_click.click();
    	Thread.sleep(2000);
    	choose_year.click();
    	Thread.sleep(2000);
    	back_calendar.click();
    	Thread.sleep(1000);
    	Click_year.click();
    	Thread.sleep(2000);
    	choose_month.click();
    	Thread.sleep(2000);
    	Select_month.click();
    	Thread.sleep(2000);
    	select_date.click();
    	Thread.sleep(2000);
    	Next_btn.click();
    	
    }
    
    public void Address_detail_3() throws Exception 
    {
    	js=(JavascriptExecutor)ldriver;
    	Thread.sleep(2000);
    	Toggle_btn.click();
    	
        Thread.sleep(2000);
    	Flat_address.sendKeys("Sion koliwada");
    	Thread.sleep(2000);
    	Landmark.sendKeys("GTB nagar");
    	Thread.sleep(2000);
    	City_selected.sendKeys("Mumbai");
    	Thread.sleep(2000);
    	State_click.click();
    	Thread.sleep(2000);
    	js.executeScript("window.scrollBy(0,200)");
    	//Thread.sleep(2000);
    	select_maha.click();
    //	Thread.sleep(1000);
    	//select_maha.sendKeys(Keys.ENTER);
    	 Thread.sleep(2000);
    	Select_pincode.sendKeys("400012");
    	Thread.sleep(1000);
    	Address_type.click();
    	Thread.sleep(1000);
    	Radio_click.click();
    	Thread.sleep(1000);
    	Address_ok.click();
    	Thread.sleep(1000);
    	
    	Next_address.click();
    	
    }
    
    public void profession_tpye() throws Exception {
    	Thread.sleep(2000);
    	Pro_type.click();
    	Thread.sleep(1000);
    	select_sal.click();
    	Thread.sleep(1000);
    	select_sal_ok.click();
    	Thread.sleep(2000);
    	monthly_income.sendKeys("50000");
    	Thread.sleep(2000);
    	company_search.sendKeys("Creditfair");
    	Thread.sleep(2000);
    	com_type.click();
    	Thread.sleep(2000);
    	select_comp.click();
    	Thread.sleep(2000);
    	select_comp_ok.click();
    	Thread.sleep(2000);
    	designation.sendKeys("QA");
    	Thread.sleep(2000);
    	department_clk.sendKeys("IT");
    	Thread.sleep(2000);
    	Next_income.click();
    	
   }
    
    public void upload_document() throws Exception {
//    	Actions act=new Actions(ldriver);
//    	Thread.sleep(2000);
//    	WebElement fileupload=ldriver.findElement(By.xpath("//span[text()=\"Bank Statement\"]"));
//    	//act.moveToElement(fileupload).click().build().perform();
//    	act.moveToElement(fileupload).sendKeys(filepath).build().perform();
//    	//fileupload.sendKeys(filepath);
//    	Thread.sleep(3000);
//    	upload_clk.click();
//    	Thread.sleep(3000);
//    	next_document.click();
//    	
    	Thread.sleep(2000);
    	Skip_clk.click();
    	
    }
}



