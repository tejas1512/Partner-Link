package XPaths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class New_centrexpath {
	WebDriver ldriver;
	
	 public OTP_authentication database;
	
	public  New_centrexpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}
	
	
	@FindBy (xpath ="(//button[@type=\"button\"])[1]")
	 WebElement dashboard_click;
	
	@FindBy (xpath = "//span[text()=\"New Center\"]")
	 WebElement New_centre;
	
	@FindBy (xpath = "//input[@id=\"cname\"]")
	 WebElement centre_name;
	
	@FindBy (xpath = "//input[@id=\"email\"]")
	 WebElement Entre_email;
	
	@FindBy (xpath = "//input[@id=\"phone\"]")
	 WebElement Entre_num;
	
	@FindBy (xpath = "//input[@id=\"location\"]")
	 WebElement Entre_location;
	
	@FindBy (xpath = "//span[text()=\"Home\"]")
	 WebElement Home_btn;
	
	
	public void Entre_newcentre() throws Exception {
		
		Thread.sleep(2000);
		dashboard_click.click();
		Thread.sleep(2000);
		New_centre.click();
		Thread.sleep(2000);
		centre_name.sendKeys("sion");
		Thread.sleep(1000);
		Entre_email.sendKeys("Nisyuyuh@gmail.com");
		Thread.sleep(2000);
		Entre_num.sendKeys("8909787899");
		Thread.sleep(1000);
		Entre_location.sendKeys("Gtb nagar");
		Thread.sleep(2000);
		Home_btn.click();
	}
	

}
