package XPaths;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class Emi_calculatorxpath {
	
	
	WebDriver ldriver;
	
	 public OTP_authentication database;
	
	public  Emi_calculatorxpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}
	
	@FindBy (xpath ="//span[text()=\"EMI \"] ")
	 WebElement EMI_clk;
	
	@FindBy (xpath = "//div[@role=\"button\"]")
	 WebElement product_name;
	
	@FindBy (xpath = "//li[text()=\"CDAC\"]")
	 WebElement clk_product;
	
	@FindBy (xpath = "//input[@id=\"loan_amount\"]")
	 WebElement loan_amount;
	
	@FindBy (xpath = "(//button[@type=\"button\"])[2]")
	 WebElement show_plans;
	
	public void Emi_cal() throws Exception {
		Thread.sleep(2000);
		EMI_clk.click();
		Thread.sleep(2000);
		product_name.click();
		Thread.sleep(2000);
		clk_product.click();
		Thread.sleep(2000);
		loan_amount.sendKeys("80000");
		Thread.sleep(2000);
		show_plans.click();
		
		
	}
	
	

}
