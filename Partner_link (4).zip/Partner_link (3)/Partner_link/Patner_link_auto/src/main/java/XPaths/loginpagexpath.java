package XPaths;

import java.sql.SQLException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class loginpagexpath extends OTP_authentication
{
	WebDriver ldriver;
	  public OTP_authentication database;
	  JavascriptExecutor js;
	
 
	public loginpagexpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}

	@FindBy (xpath = "//div[@type=\"button\"]")
	 WebElement letsstarted;
	
	@FindBy (xpath = "//div[@type=\"button\"]")
	 WebElement next;
	
	@FindBy (xpath = "//div[@type=\"button\"]")
	 WebElement next1;
	
	@FindBy (xpath = "//div[@type=\"button\"]")
	 WebElement okgotit;
	
	@FindBy (xpath = "//input[@id=\"phone\"]")
	 WebElement mob_number;
	

	@FindBy (xpath = "(//button[@type=\"button\"])[1]")
	 WebElement login_btn;
	
	@FindBy (xpath = "//input[@id=\"otp\"]")
	 WebElement enter_otp;
	
	@FindBy (xpath = "(//button[@type=\"button\"])[1]")
	 WebElement confirm_otp;
	
	@FindBy (xpath = "(//span[@class=\"jss926\"])[2]")
	 WebElement resend_otp;
	

	@FindBy (xpath ="(//button)[22]")
	 WebElement close_link;
	
	@FindBy (xpath ="(//button[@type=\"button\"])[1]")
	 WebElement dashboard_click;
	
	
	@FindBy (xpath = "//span[text()=\"Logout\"]")
	 WebElement logout;
	
	
	
	
	
	public void logincredentials() throws Exception, Exception
	
	
	{ 
		js=(JavascriptExecutor)ldriver;
		 
				
	    Thread.sleep(2000);
		letsstarted.click();
		Thread.sleep(1000);
        next.click();
        Thread.sleep(1000);

		next1.click();
		Thread.sleep(1000);

		okgotit.click();
		Thread.sleep(1000);

		mob_number.sendKeys("8928325409");
		login_btn.click();
        Thread.sleep(1000);
		enter_otp.click();
		super.Db_connect();
		System.out.println(otp);
		Thread.sleep(1000);
		enter_otp.sendKeys(otp);
		Thread.sleep(3000);
		confirm_otp.click();
		Thread.sleep(3000);
		close_link.click();
		Thread.sleep(2000);
		dashboard_click.click();
		 js.executeScript("window.scrollBy(0,100)");
		Thread.sleep(2000);
		
		logout.click();
		
	}
	
public void login_detail() throws Exception, Exception
	
	
	{ 
		
		 
				
	    Thread.sleep(3000);
		letsstarted.click();
		Thread.sleep(1000);
        next.click();
        Thread.sleep(1000);

		next1.click();
		Thread.sleep(1000);

		okgotit.click();
		Thread.sleep(1000);

		mob_number.sendKeys("8928325409");
		login_btn.click();
        Thread.sleep(1000);
		enter_otp.click();
		super.Db_connect();
		System.out.println(otp);
		Thread.sleep(1000);
		enter_otp.sendKeys(otp);
		Thread.sleep(3000);
		confirm_otp.click();
		Thread.sleep(4000);
		close_link.click();
		Thread.sleep(2000);
		
}
	
	
	
	
	
	
	
	
	
	
	
	



}
