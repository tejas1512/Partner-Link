package XPaths;
import java.sql.SQLException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class Application_view 
{
	WebDriver ldriver;
	  public OTP_authentication database;
	  
	  JavascriptExecutor js;
	
	

	public Application_view(WebDriver rDriver) 
	{

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
    }
	
	@FindBy (xpath = "//h2[text()=\"Applications Approved\"]")
	 WebElement click_1;
	
	
	@FindBy (xpath = "//span[text()=\"PRATIK BENDAL\"]")
	WebElement Approved_link;
	
	@FindBy (xpath = "//span[text()=\"EDIT\"]")
	 WebElement edit_loan_details;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_edit_loan;
	
	@FindBy (xpath = "(//span[text()=\"EDIT\"])[2]")
	 WebElement Edit_personal_loan;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_personal;
	
	@FindBy (xpath = "(//span[text()=\"EDIT\"])[3]")
	 WebElement Edit_address;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_address;
	
	@FindBy (xpath = "(//span[text()=\"EDIT\"])[4]")
	 WebElement Edit_income_detail;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_income;
	
	@FindBy (xpath = "(//span[text()=\"EDIT\"])[5]")
	 WebElement Edit_document_proof;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_document_proof;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_home_page_1;
	
	@FindBy (xpath = "(//span[contains(@class,\"\" )])[3]")
	 WebElement back_home_page_2;
	
	public void xpath_homepage() throws Exception {
		
		js=(JavascriptExecutor)ldriver;

		click_1.click();
		Thread.sleep(2000);
		js.executeScript("arguments[0].click();",Approved_link);
		//Approved_link.click();
		Thread.sleep(2000);
		edit_loan_details.click();
		Thread.sleep(2000);
		back_edit_loan.click();
		Thread.sleep(1000);
		Edit_personal_loan.click();
		Thread.sleep(2000);
		back_personal.click();
		Thread.sleep(1000);
		Edit_address.click();
		System.out.println("Address is invisisble");
		Thread.sleep(1000);
		back_address.click();
		Thread.sleep(1000);
		Edit_income_detail.click();
		Thread.sleep(1000);
		back_income.click();
		Thread.sleep(1000);
		Edit_document_proof.click();
		Thread.sleep(1000);
		back_document_proof.click();
		Thread.sleep(1000);
		back_home_page_1.click();
		Thread.sleep(1000);
		back_home_page_2.click();
		
	
		
		
	}
	
	
	
	
	
		
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
}
