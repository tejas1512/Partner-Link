package XPaths;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Database_connectivity.OTP_authentication;

public class MIS_REPORT {
	
	 WebDriver ldriver;
	 public OTP_authentication database;
	  
	  JavascriptExecutor js;
	
public MIS_REPORT (WebDriver rDriver) 
	{

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
   }
//From date

@FindBy (xpath ="(//button[@type=\"button\"])[1]")
WebElement dashboard_click;

@FindBy (xpath ="//span[text()=\"Generate MIS\"]")
WebElement MIS_re_clk;

@FindBy (xpath ="(//input[@type=\"date\"])[1]")
WebElement clk_date1;

@FindBy (xpath ="(//input[@type=\"date\"])[2]")
WebElement clk_date2;


@FindBy (xpath = "//a[@title=\"Choose a year\"]")
WebElement choose_year;

@FindBy (xpath = "//a[text()=\"2023\"]")
WebElement sel_2023 ;

@FindBy (xpath = "//a[@title=\"Choose a month\"]")
WebElement choose_month ;

@FindBy (xpath = "//a[text()=\"Dec\"]")
WebElement Sel_month;

@FindBy (xpath = "//div[text()=\"23\"]")
WebElement select_date;

//To date
@FindBy (xpath = "//a[@title=\"Choose a year\"]")
WebElement choose_Yea;

@FindBy (xpath = "(//a[text()=\"2024\"])[2]")
WebElement sel_2024 ;

@FindBy (xpath = "//a[@title=\"Choose a month\"]")
WebElement choose_month1 ;

@FindBy (xpath = "(//a[text()=\"Jan\"])[2]")
WebElement Sel_Jan;

@FindBy (xpath = "//div[text()=\"11\"]")
WebElement select_day;

@FindBy (xpath = "//span[text()=\"Send MIS report on Email \"]")
WebElement Send_report;

@FindBy (xpath = "//span[text()=\"Ok\"]")
WebElement ok_click;

//span[text()="Ok"]




public void Mis_date_from() throws Exception {
	Thread.sleep(2000);
	dashboard_click.click();
	Thread.sleep(2000);
	MIS_re_clk.click();
	Thread.sleep(1000);
	clk_date1.click();
	
	Thread.sleep(2000);
	choose_year.click();
	Thread.sleep(2000);
	sel_2023.click();
	Thread.sleep(2000);
	choose_month.click();
	Thread.sleep(1000);
	Sel_month.click();
	Thread.sleep(1000);
	select_date.click();
	
}

public void To_date() throws Exception {
	Thread.sleep(2000);
	clk_date2.click();
	Thread.sleep(2000);
	choose_Yea.click();
	Thread.sleep(2000);
	sel_2024.click();
	Thread.sleep(2000);
	choose_month1.click();
	Thread.sleep(2000);
	Sel_Jan.click();
	Thread.sleep(1000);
	select_day.click();
	Thread.sleep(1000);
	Send_report.click();
	Thread.sleep(1000);
	ok_click.click();
	
}




}
