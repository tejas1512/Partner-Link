package BrowserSetup;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.decorators.WebDriverDecorator;

import io.cucumber.messages.types.Product;


public class ChromeBrowser {
	
	static WebDriver driver;
	public void openWeb() {
		
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
	}
	public static void main(String[] args) {
		
	
	
		
		List<WebElement> product_items=driver.findElements(By.xpath("//h2[@class='product-title']"));
		
		WebElement prod = product_items.stream().filter(product -> product.findElement(By.cssSelector("b")).getText().equals("")).findFirst().orElse(null);
		prod.findElement(By.cssSelector("")).click(); 
		for (Iterator<WebElement> iterator = product_items.iterator(); iterator.hasNext();) {
			
		}
		
		
	}

}
