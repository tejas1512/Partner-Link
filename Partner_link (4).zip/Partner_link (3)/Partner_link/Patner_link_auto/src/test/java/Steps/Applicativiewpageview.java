package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.Application_view;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Applicativiewpageview {
	
	public loginpagexpath xpath;
	WebDriver driver;
	public Application_view dashxapth;
	
	@Given("User Open browser")
	public void user_open_browser() {
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
		dashxapth= new Application_view(driver);
	    
	}

	@Then("User Enter url {string}")
	public void user_enter_url(String url) throws Exception {
		Thread.sleep(2000);
		driver.get(url);
	  
	}

	@When("User Enter valid mobile number")
	public void user_enter_valid_mobile_number() throws Exception {
		xpath.login_detail();
	  
	}

	@Then("User click to view the application")
	public void user_click_to_view_the_application() throws Exception {
		dashxapth.xpath_homepage();
		Thread.sleep(1000);
		driver.quit();
	   
	}


}
