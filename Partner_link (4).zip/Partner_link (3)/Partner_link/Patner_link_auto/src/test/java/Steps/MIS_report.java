package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.CreateAppXpath;
import XPaths.MIS_REPORT;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MIS_report {
  
	public loginpagexpath xpath;
	public MIS_REPORT xpath1;
	WebDriver driver;
	
	@Given("User Opened Browser")
	public void user_opened_browser() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
		xpath1=new MIS_REPORT(driver);
	  
	}

	@Then("User Entered url {string}")
	public void user_entered_url(String url) throws Exception {
		Thread.sleep(2000);
		driver.get(url);
	  
	}

	@When("User Enters Valid mobile_number")
	public void user_enters_valid_mobile_number() throws Exception {
		xpath.login_detail();
	   
	}

	@Then("User click to MIS_report")
	public void user_click_to_mis_report() throws Exception {
		xpath1.Mis_date_from();
		xpath1.To_date();
		Thread.sleep(2000);
		driver.quit();
	    
	}



}
