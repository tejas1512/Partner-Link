package Steps;

import java.awt.Dimension;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import Database_connectivity.OTP_authentication;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class oneValid_Login_credentials 
{ 
	public loginpagexpath xpath;
	public WebDriver driver;
	public OTP_authentication otp;
	
	
	@Given("Open browser")
	public void open_browser() 
	{

//    	WebDriverManager.firefoxdriver().setup();
//        driver=new FirefoxDriver();
//		driver.manage().window().maximize();
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
	}

	@Then("Enter url {string}")
	public void enter_url(String url) throws InterruptedException 
	{ 
	 Thread.sleep(2000);
	  driver.get(url);
	}

	@When("Enter valid mobile number")
	public void enter_valid_user_credentials() throws Exception 
	{
	   xpath.logincredentials();
	   Thread.sleep(2000);
	   driver.close();
	}
}
