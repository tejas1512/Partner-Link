package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.Application_view;
import XPaths.Track_xpath;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Track_Application {
	
	public loginpagexpath xpath;
	WebDriver driver;
	public  Track_xpath xpath1;
	@Given("User Opened browser")
	public void user_opened_browser() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
		xpath1=new Track_xpath(driver);
	   
	}

	@Then("User Enter urls {string}")
	public void user_enter_urls(String url) throws Exception {
		Thread.sleep(2000);
		driver.get(url);
	   
	}

	@When("User Enter valids mobile number")
	public void user_enter_valids_mobile_number() throws Exception {
		xpath.login_detail();
	   
	}

	@Then("User click to Track the application")
	public void user_click_to_track_the_application() throws Exception {
		xpath1.Event_Track();
		Thread.sleep(1000);
		xpath1.search_Event();
		Thread.sleep(2000);
		driver.quit();
	   
	}

}
