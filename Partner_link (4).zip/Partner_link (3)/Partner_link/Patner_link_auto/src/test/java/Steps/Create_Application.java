package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.CreateAppXpath;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Create_Application {
	
	public loginpagexpath xpath;
	public CreateAppXpath xpath_create;
	WebDriver driver;
	
	
	
	@Given("User Opened browsers")
	public void user_opened_browsers() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
		xpath_create=new CreateAppXpath(driver);
	}

	@Then("User Enters urls {string}")
	public void user_enters_urls(String url) {
	  driver.get(url);
	}

	@When("User Enters valids mobile number")
	public void user_enters_valids_mobile_number() throws Exception {
	    xpath.login_detail();
	}

	@Then("User click to Create_Appliaction")
	public void user_click_to_create_appliaction() throws Exception {
		xpath_create.loan_detail_1();
		xpath_create.personal_details_2();
		xpath_create.Rc_Calendar_2();
		xpath_create.Address_detail_3();
		xpath_create.profession_tpye();
		xpath_create.upload_document();
		driver.quit();
	  
	}


}
