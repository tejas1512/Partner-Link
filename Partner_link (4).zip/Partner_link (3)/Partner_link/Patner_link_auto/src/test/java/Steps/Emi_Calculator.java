package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.Emi_calculatorxpath;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Emi_Calculator {
	
	
	public loginpagexpath xpath;
	public WebDriver driver;
	public Emi_calculatorxpath xpath1;
	
	
	@Given("Users Opened Browse")
	public void users_opened_browse() {
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
		xpath1=new Emi_calculatorxpath(driver);
	   
	}

	@Then("User Enter_Urls {string}")
	public void user_enter_urls(String url) throws Exception {
		Thread.sleep(2000);
		driver.get(url);
	  
	}

	@When("User Enters Valids Mobile_number")
	public void user_enters_valids_mobile_number() throws Exception {
		xpath.login_detail();
	    
	}

	@Then("User click to Emi_calculator")
	public void user_click_to_emi_calculator() throws Exception {
		
		xpath1.Emi_cal();
		Thread.sleep(2000);
		driver.quit();
		
	   
	}


}
