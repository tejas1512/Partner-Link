package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.New_centrexpath;
import XPaths.New_userxpath;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateNewcentre {
	
	public WebDriver driver;
	public loginpagexpath xpath;
	public New_centrexpath xpath1;
	
	
	@Given("Users Opened browsers")
	public void users_opened_browsers() {
		
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
        xpath1= new New_centrexpath(driver);

	   
	}

	@Then("User Enter_urls {string}")
	public void user_enter_urls(String url) throws Exception {
		Thread.sleep(2000);
		driver.get(url);
	    
	}

	@When("User Enters valids mobile_number")
	public void user_enters_valids_mobile_number() throws Exception {
		xpath.login_detail();
		
	   
	}

	@Then("User click to CreateNew centre")
	public void user_click_to_create_new_centre() throws Exception {
		xpath1.Entre_newcentre();
		Thread.sleep(2000);
		driver.quit();
	    
	}



}
