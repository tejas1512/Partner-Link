package Steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import XPaths.CreateAppXpath;
import XPaths.New_userxpath;
import XPaths.loginpagexpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class NewUsercreate {
	public loginpagexpath xpath;
	public WebDriver driver;
	public New_userxpath xpath1;
	
	
	@Given("Users Opene browser")
	public void users_opene_browser() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		//Dimension dimension = new Dimension(800, 600);
		driver.manage().window().maximize();
		xpath=new loginpagexpath(driver);
        xpath1= new New_userxpath(driver);

}

	@Then("User Enter_url {string}")
	public void user_enter_url(String url) throws InterruptedException {
		Thread.sleep(2000);
		driver.get(url);
		
	   
	}

	@When("User Enters valids_mobile number")
	public void user_enters_valids_mobile_number() throws Exception {
		xpath.login_detail();
	    
	}

	@Then("User click to newUser_create")
	public void user_click_to_new_user_crate() throws Exception {
		xpath1.Adduser();
		Thread.sleep(2000);
		driver.quit();
	   
	}

}
